import math
def surface_area(radius):
    return 4*math.pi*radius**2
def volume(radius):
    return(4/3)*math.pi*radius**3
