import math
def area(radius):
    return math.pi*radius**2
def perimeter(radius):
    return 2*math.pi*radius
